
# coding: utf-8

# In[1]:


from Runnable import ReviewAnalyser
# from df_convert import getDataFrame
import pandas as pd


# In[4]:


df = getDataFrame(["B072JBQFWQ"])


# In[5]:


df.to_csv("tmp.csv")


# In[2]:


df = pd.read_csv("tmp.csv")
ra = ReviewAnalyser(df["review_text"])
ra.startProcessing()


# In[9]:


def get_printable_category_verb(category): 
    a =  ra.new_adj_verb_df[ra.new_adj_verb_df["category"] == "quality"]
    a = a.groupby(["word"])[["count"]].sum()
    a["word"] = a.index
    print("\n".join("word: {0}, occurrence: {1}".format(t["word"], t["count"]) for i,  t in a.iterrows()))

