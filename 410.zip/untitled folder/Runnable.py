
# coding: utf-8

# In[766]:


from spacy.en import English
import pandas as pd
import numpy as np
import re
import time
from nltk.corpus import wordnet
from sklearn.cluster import KMeans, AgglomerativeClustering, DBSCAN
import itertools
from collections import Counter, defaultdict
from sklearn.neighbors import KNeighborsClassifier
from nltk.sentiment.util import mark_negation
from  string import punctuation
from nltk.corpus import stopwords
from fuzzywuzzy import fuzz


# In[12]:


nlp = English()


# In[410]:


# data = pd.read_csv("Womens Clothing E-Commerce Reviews.csv")[:1200]


# # ### Helper Function for Data Cleaning

# In[716]:


def extract_first_elem_text(long_list):
    # input is ("noun/obj", *)
    merged_list = list(itertools.chain.from_iterable(long_list))
    return list(map(lambda x: x[0].lemma_ if x[0] != "OBJECT" else "OBJECT", merged_list))
def extract_second_elem_text(long_list):
    # input is (*, *)
#     merged_list = list(itertools.chain.from_iterable(long_list))
    return list(map(lambda x: x[1] , long_list))

#---------------------------------------------------------------------------------
def get_syns_metric(p1, p2, pos):
    a1 = wordnet.synsets(p1, pos=pos)
    a2 = wordnet.synsets(p2, pos=pos)
    result_org = .05
    result = result_org
    if len(a1) and len(a2):
        result = wordnet.wup_similarity(a1[0],a2[0])
    else:
        if len(a2):
            a1 = wordnet.synsets(re.split("\W+", p1)[0], pos=pos)
        else:
            a2 = wordnet.synsets(re.split("\W+", p2)[0], pos = pos)
        if len(a1) and len(a2):
            result = wordnet.wup_similarity(a1[0],a2[0])
    if result:
        return result
    else:
        return result_org
def get_vector_dist(words, pos):
    # get the vectors 
    dist_vector = -1*np.array([[get_syns_metric(w1,w2, pos) for w1 in words] for w2 in words])
    return dist_vector

#---------------------------------------------------------------------------------

def pick_to_seed_noun_list(adj_list, seed_list, pos):
    # expand the noun seed set
    adj_list_copy = adj_list.copy()
    s1 = len(seed_list)
    s2 = 0
    while s1 != s2:
        s1 = len(seed_list)
        seed_list = expand_seed_noun_list(adj_list_copy, seed_list, pos)
        s2 = len(seed_list)
    return seed_list
def expand_seed_noun_list(adj_list, seed_list, pos):
    i = 0
    while i < len(adj_list):
        flag= 0
        adj = adj_list[i]
        for seed in seed_list:
            a1 = wordnet.synsets(adj, pos=pos)
            a2 = wordnet.synsets(seed, pos=pos)
            if len(a1) and len(a2):
                result = wordnet.wup_similarity(a1[0],a2[0])
                if result > 0.75:
#                     print(adj, seed, result)
                    seed_list.append(adj)
                    adj_list = np.delete(adj_list, adj)
                    flag = 1
                    break
        if not flag:
            i+=1
    return seed_list

#---------------------------------------------------------------------------------
def pick_to_seed_adj_list(adj_list, seed_list, pos):
    adj_list_copy = adj_list.copy()
    s1 = len(seed_list)
    s2 = 0
    while s1 != s2:
        s1 = len(seed_list)
        seed_list = expand_seed_noun_list(adj_list_copy, seed_list, pos)
        s2 = len(seed_list)
    return seed_list
def expand_seed_adj_list(adj_list, seed_list, pos):
    i = 0
    while i < len(adj_list):
        flag= 0
        adj = adj_list[i]
        for seed in seed_list:
            result = get_syns_metric(adj, seed, pos)
            if result > 0.75:
                seed_list.append(adj)
                adj_list.remove(adj)
                flag = 1
                break
        if not flag:
            i+=1
    return seed_list
#---------------------------------------------------------------------------------
def pick_to_sentiment_word(adj_list, seed_list_pos_old):
    adj_list_copy = list(adj_list.copy())
    seed_list_pos = set(seed_list_pos_old)
    s1 = len(seed_list_pos)
    s2 = 0
    while s1 != s2:
        s1 = len(seed_list_pos)
        expand_sentiment_list(adj_list_copy, seed_list_pos)
        s2 = len(seed_list_pos)
    return seed_list_pos
def expand_sentiment_list(adj_list, seed_list_pos):
    i = 0
    while i < len(adj_list):
        flag= 0
        adj = adj_list[i]
        for seed in seed_list_pos:
            
            a1 = wordnet.synsets(str(seed), pos="a")
            a2 = wordnet.synsets(str(adj), pos="a")
            if len(a1) and len(a2):
                print(seed, adj)
                result = wordnet.wup_similarity(a1[0],a2[0])
                print(result)
                if result and result > 0.5:
                    seed_list_pos.add(adj)
                    adj_list.remove(adj)
                    flag = 1
                    break
        if not flag:
            i+=1

#----------------------------------------------------------------------------------
def get_antonyms(words, pos):
    def get_antonyms_sub(word, pos):
        syns = wordnet.synsets(word, pos=pos)
        if len(list(syns)) > 0 and len(syns[0].lemmas()) > 0:
            sing_lemma = syns[0].lemmas()[0]
            return set(map(lambda x:x.name(), sing_lemma.antonyms()))
        else:
            return set()
    word_set = set(words)
    result = list(map(lambda x: get_antonyms_sub(x, pos), word_set))
#     print(result)
    word_set = word_set.union(*result)
    return list(word_set)

#-----------------------------------------------------------------------------------
def get_category_adj(category, df, item_adj_dict):
    items = df["word"][df["category"] == category].values
    return list(set(list(map(lambda x: item_adj_dict[x], items))))

#-----------------------------------------------------------------------------------
def construct_dict(picked_item, item_adj_list):
    output_dict =  defaultdict(set)
    output_dict_adv = defaultdict(set)
    cur_adjs = []
    for item in picked_item:
#         print(item_adj_list)
        cur_adjs += [x[1] for x in list(filter( lambda x: str(x[0]) == item, item_adj_list))]
        if cur_adjs:
            l = list(itertools.chain.from_iterable(cur_adjs))
            for ll in l:
                output_dict[item].add(ll[0])
                output_dict_adv[str(item)+"_"+str(ll[0])].add(", ".join(list(map(str, ll[1]))))
#             map(lambda x: output_dict[item].add(x), l)
        cur_adjs = []
    return [output_dict, output_dict_adv] # the second output is noun_adj: adv

#-----------------------------------------------------------------------------------
def parse_size_opinion(doc):
    # single review
    result = ""
    sent_list = [sent for sent in doc.sents]
    fg = 0
    for i, sent in enumerate(sent_list):
        if bool(re.search("5'+\d", sent.string.strip())):
            if i > 0:
                if any(x in str(sent_list[i-1]) for x in size_keywords):
                    result += sent_list[i-1].string.strip() + " "
            result += sent.string.strip()
            if i < len(sent_list)-1:
                
                if any(x in str(sent_list[i+1]) for x in size_keywords):
                    result+= " "+sent_list[i+1].string.strip()
            fg = 1
            break
    if fg:
        return (re.findall("5'+\d", sent.string.strip())[0], result)


# In[728]:


# texture_sentiment_pos

# ## Build the Lexicon


texture_list = ["texture", "cloth", "feeling", "fabric", "cotton", "denim", "material"]
quality_list = [ "quality", "feeling", "touching", "touch"]
part_list = ["part", "sleeves", "collar", "button", "knit", "strap", "tie", "lace", "layer", "heel","portion"]
product_list = ["sweater", "dress", "shirt", "pant", 'bra', "jacket", 'coat']
color_list = ["color", "colour", "hue", "blue"]
design_list = ["length", "design", "dot", "lining", "stripe", "pattern", "print", "drape", "style"]


texture_adj_list = [ "tough", "hard", "silky", "soft", "clingy", "sheer"]
quality_adj_list = ["comfy", "comfortable","cheap", "careful", "thick","thin", "lightweight", "expensive", "worthy"]
general_adj_list = ["pricey","gorgeous","amazing", "sexy", "flattering", "feminine", "disappointed","disappointing", "pretty",                    "cute", "unique", "versatile","sporty", "great", "perfect", "bad"]
size_adj_list = ["large", "short", "tall", "long", "oversized", "small", "wide","tight", "petite"]
design_adj_list = ["sloppy", "loose", "puffy", "delicate", "simple", "classic", "transparent", "quirky", "floral", "roomy", "cool"]

# can be used when parsing new reviews
pos_opinion_verb = ["like", "admire", "appreciate", "love"]
neg_opinion_verb = ["dislike", "hate", "like_NEG"]

# size keywords
size_keywords = ["fit", "fits", "run", "runs", "length", "size"] + size_adj_list


# In[485]:


cloth_word = ["wear", "cloth", "ornament", "garment", "coat", "footwear", "headdress", "dress", ]
size_word = size_keywords
common_size_verb = ["fit", "fits", "run", "runs"]
common_general_verb = ["look", "looks", "feel", "feels"]
reg_num = re.compile(r'\d')
stop_words = set(stopwords.words('english'))


# ### Parse Adj and Nouns

# In[796]:


def parse_review(text_data, adj_noun_list,adjs_verbs_list,like_noun, dislike_noun, size_info = [], recommended_pair = [], new_review = True):
    for text in text_data:
        if text[-1] not in punctuation:
            text += "."
        cur_adj_noun_list = []
        docs = nlp(text)
        # need to handle negation!!!!!
        # wonder if we need to filter the stop word? 
        for doc in docs: # for nouns we also need to check its verb. for example, love this shirt. or we could do subjective verb 
            neg_sent = 0
            if doc.pos_[0]=="N" or doc.lemma_=="it" or doc.lemma_=="they": # most basic, extract adj + noun phrase
                for a in doc.ancestors:
                    if a.dep_ == "ROOT" and a.pos_=="VERB" and len(a) > 1 and a.text != docs[-1].text and a.nbor().dep_=="neg" :
                        neg_sent = 1
                sub_comp_list = []
                noun_list = [doc] + [c for c in doc.conjuncts]
                for c in doc.lefts:
                    if c.dep_ == "amod" and not bool(re.search(r'\d', c.text)): # cool shirt! 
                        if neg_sent:
                            sub_comp_list += [(c, ["NOT"]+list( c.children))]+[(cj, ["NOT"]+list(cj.children)) for cj in c.conjuncts]
                        else:
                            sub_comp_list += [(c, list( c.children))]+[(cj, list(cj.children)) for cj in c.conjuncts]
                if doc.dep_ == "nsubj": # shirt is cool
                    verb_of_noun = [c for c in doc.ancestors][0]
                    for c in verb_of_noun.children:
                        if c.dep_ == "acomp":
                            if not neg_sent:
                                sub_comp_list += [(c, list(c.children))]+[(cj, list(cj.children)) for cj in c.conjuncts]
                            else:
                                sub_comp_list += [(c, ["NOT"]+list( c.children))]+[(cj, ["NOT"]+list(cj.children)) for cj in c.conjuncts]
#                             sub_comp_list += [(c, list(c.children))]+[(cj, list(cj.children)) for cj in c.conjuncts]
                if len(sub_comp_list) > 0:
                    cur_adj_noun_list = list(map(lambda x: (x, sub_comp_list) if x.lemma_ != "it" and x.lemma_ != "they" else ("OBJECT", sub_comp_list) , noun_list))
                    adj_noun_list.append(cur_adj_noun_list)

                if not set(pos_opinion_verb).isdisjoint([a.text for a in doc.ancestors]):
                    like_noun.append(doc)
                elif not set(neg_opinion_verb).isdisjoint([a.text for a in doc.ancestors]):
                    dislike_noun.append(doc)

            if doc.pos_ == "ADJ" and (doc.dep_ in ["ROOT", "amod","acomp" ]): 

                sub_comp_list = []
                adj_list = []
                verb_list = []
                ac_count = 0
                for ac in doc.ancestors:# parse verbs like Looks great
                    ac_count += 1
                    if ac.pos_ == "NOUN":
                        break
                    if ac.pos_ == "VERB" and ac.n_lefts == 0 and ac.lemma_ in common_size_verb + common_general_verb:
                        adj_list.append(doc )
                        verb_list += [ac] + [cj for cj in ac.conjuncts]
                if ac_count==0: #parse Great and Awesome! 
                    adj_list += [doc] + [cj for cj in doc.conjuncts]
                if len(adj_list) >0:
                    sub_comp_list =list(map(lambda x: (x, adj_list) , verb_list if len(verb_list) > 0 else ["OBJECT"]))
                    adjs_verbs_list.append(sub_comp_list)

        if new_review:
            for nc in docs.noun_chunks: # append the paired clothes
                for sig_n in list(nc)[::-1]:
                    if sig_n.pos_=="NOUN":
                        syns = wordnet.synsets(sig_n.text, pos="n")
                        if len(syns) == 0:
                            continue
                        for cw in cloth_word:
                            if wordnet.wup_similarity(wordnet.synsets(cw)[0],syns[0]) > 0.7:
                                recommended_pair.append(nc.text)
                                break
            size_info.append(parse_size_opinion(docs))
            


# In[430]:


# adj_noun_list = []
# recommended_pair = []
# adjs_verbs_list = []
# like_noun = []
# dislike_noun = []
# t0 = time.time()
# data = data.dropna(subset=["Review Text"])
# data['Review Text'] = data['Review Text'].apply(lambda x: re.sub(r"\n|\.{6}", " ", x))
# parse_review(data["Review Text"], adj_noun_list,adjs_verbs_list,like_noun, dislike_noun, new_review = False)
# t1 = time.time()
# print(t1-t0)


# # ##### get 2 vectors, we first deal with the nouns and their adj

# # In[641]:


# # step 1 get the noun list and count them, then we get the most frequent 100 nouns
# # also need to take into account the like and dislike noun
# noun_only = extract_first_elem_text(adj_noun_list) + list(map(str, like_noun)) + list(map(str, dislike_noun))
# noun_only = list(filter(lambda x:( (len(x)>2 )& (not bool(re.search(r"\d", str(x)))) & (not str(x) in stop_words)) ,                        noun_only))
# noun_100_freq = Counter(noun_only).most_common(101) # the current struct is a list of tuples
# noun_only_100 = [str(x[0]) for x in noun_100_freq]
# noun_only_100.remove("OBJECT")


# # In[642]:


# # step 2 we add the top 100 noun to the seed noun and get their labels as well
# noun_label_df = pd.DataFrame({"word": texture_list + quality_list + part_list +  color_list + design_list,                                  "category": ["texture"]*len(texture_list) + ["quality"] * len(quality_list) + ["part"] * len(part_list) +                                ["color"] * len(color_list) + ["design"] * len(design_list)})
# t2 = time.time()
# noun_vector = get_vector_dist(np.append(noun_label_df["word"].values, noun_only_100), pos="n")
# print(time.time()-t2)

# t3 = time.time()
# knn_clf = KNeighborsClassifier()
# knn_clf.fit(noun_vector[:len(noun_label_df)], noun_label_df["category"])
# noun_adj_df = pd.DataFrame({"word":np.append(noun_label_df["word"].values, noun_only_100), "category":np.append(noun_label_df["category"], knn_clf.predict(noun_vector[len(noun_label_df):])) })
# print(time.time()-t3)


# # ##### do the same thing for adjs from verbs, in this case, adjs that have Obj as their verbs should be filtered out.

# # In[643]:


# # step 1: first get the antonyms of each adj
# t2 = time.time()
# texture_adj_list = get_antonyms(texture_adj_list, "a")
# quality_adj_list = get_antonyms(quality_adj_list, "a")
# general_adj_list = get_antonyms(general_adj_list, "a")
# size_adj_list = get_antonyms(size_adj_list, "a")
# design_adj_list = get_antonyms(design_adj_list, "a")
# print(time.time()-t2)


# # In[644]:


# # add OBJ from above
# old_OBJ_list = list(filter(lambda x: x[0]=='OBJECT', itertools.chain.from_iterable(adj_noun_list)))
# old_adj_list_above = [str(x[0]).lower() for y in old_OBJ_list for x in y[1]]
# # old_adj_list_above = list(itertools.chain.from_iterable(extract_second_elem_text(old_OBJ_list)))

# # step 2: deal with the output from above, first remove the OBJ adjs, then get the count and get the 80 most freq

# adj_OBJECT = list(filter(lambda x:str(x[0]) in ["OBJECT", "look", "feel", "looks", "feels"] and len(x[0]) > 2, itertools.chain.from_iterable(adjs_verbs_list)))
# adj_only_count = Counter(old_adj_list_above + list(map(lambda x: str(x).lower(), itertools.chain.from_iterable(extract_second_elem_text(adj_OBJECT)))))
# adj_80_freq = adj_only_count.most_common(80)
# adj_only_80 = [str(x[0]) for x in adj_80_freq]

# # for the adjs that already have a verb, we could classify them with the verbs
# # the verbs include: Look, Feel, Run, Fit
# adj_kept_by_size = list(filter(lambda x: str(x[0]) in ["run", "fit"], itertools.chain.from_iterable(adjs_verbs_list)))
# adj_only_kept_by_size = list(itertools.chain.from_iterable(extract_second_elem_text(adj_kept_by_size)))
# adj_verb_df = pd.DataFrame({"word": adj_only_kept_by_size, "category":["size"] * len(adj_only_kept_by_size)})



# # In[645]:


# # step 3 we add the top 80 adjs to the seed adj and get their label as well.
# t3 = time.time()

# adj_list_df = pd.DataFrame({"word": texture_adj_list + quality_adj_list + general_adj_list +  size_adj_list + design_adj_list,                                  "category": ["texture"]*len(texture_adj_list) + ["quality"] * len(quality_adj_list) + ["general"] * len(general_adj_list) +                                ["size"] * len(size_adj_list) + ["design"] * len(design_adj_list)})
# print(time.time()-t3)

# t3 = time.time()
# adj_vector = get_vector_dist(np.append(adj_list_df["word"].values, adj_only_80), pos="a")

# knn_verb_clf = KNeighborsClassifier(n_neighbors=2)
# knn_verb_clf.fit(adj_vector[:len(adj_list_df)], adj_list_df["category"])
# adj_verb_df_tmp = pd.DataFrame({"word":np.append(adj_list_df["word"].values, adj_only_80),                                               "category":np.append(adj_list_df["category"], knn_verb_clf.predict(adj_vector[len(adj_list_df):]))},                                             )
# adj_verb_df = adj_verb_df_tmp.append(adj_verb_df,ignore_index = True)
# adj_verb_df["word"] = adj_verb_df["word"].apply(str)


# # In[537]:


# # Now we have nouns that has thier own category and adjs that has their own category, when parsing new reviews, 
# # we could use hte dist to cluster the new nouns and adjs and produce a bunch of tuple in that category
# # we are like finish building a lexicon


# # ### Next, we need some adj for each category to do the "sentiment analysis", 
# # #### the category incudes texture, quality, general, size, design, part, color

# # In[717]:


# # texture_sentiment_pos = ["like", "love","comfortable","soft","puffy","sturdy"]
# # texture_sentiment_neg = ["hate", "itchy","tight"]
# # quality_sentiment_pos = ["like", "love", "expensive"]
# # quality_sentiment_neg = ["hate","cheap","poor"]
# # design_sentiment_pos = ["like", "love","beautiful","vibrant","cute"]
# # design_sentiment_neg = ["hate", "baggy"]
# # general_sentiment_pos = ["like", "love","great","perfect","suitable","delightful","gorgeous","fabulous"]
# # general_sentiment_neg = ["hate", "unflattering", "unfashionable","uncomfortable","outdated","stained", "disappointing"]


# # # call the expand function on them respectively. Also, the adj_list are:
# # adj_sets = adj_verb_df['word'][adj_verb_df["category"]=="texture"]
# # texture_sentiment_pos = pick_to_sentiment_word(adj_sets,texture_sentiment_pos )
# # texture_sentiment_neg  = pick_to_sentiment_word(adj_sets,texture_sentiment_neg)

# # adj_sets = adj_verb_df['word'][adj_verb_df["category"]=="quality"]
# # quality_sentiment_pos = pick_to_sentiment_word(adj_sets,quality_sentiment_pos )
# # quality_sentiment_neg  = pick_to_sentiment_word(adj_sets,quality_sentiment_neg)

# # adj_sets = adj_verb_df['word'][adj_verb_df["category"]=="design"]
# # design_sentiment_pos = pick_to_sentiment_word(adj_sets,design_sentiment_pos )
# # design_sentiment_neg  = pick_to_sentiment_word(adj_sets,design_sentiment_neg)

# # adj_sets = adj_verb_df['word'][adj_verb_df["category"]=="general"]
# # general_sentiment_pos = pick_to_sentiment_word(adj_sets,general_sentiment_pos )
# # general_sentiment_neg  = pick_to_sentiment_word(adj_sets,general_sentiment_neg)
# # # we could use the sentiment to do a overall evaluation of the new reivew




# # ## Parsing a new product Review!!!!

# # ##### First let's parse the data

# # In[739]:


def run_the_long_process(newdata):

    new_adj_noun_list = []
    new_recommended_pair = []
    new_adjs_verbs_list = []
    new_like_noun = []
    new_dislike_noun = []
    new_size_info = []
    t0 = time.time()
    # change here !!
    # newdata =  pd.read_csv("Womens Clothing E-Commerce Reviews.csv")[1300:1310].dropna(subset=["Review Text"])
    noun_adj_df = pd.read_csv("noun_adj_df.csv")
    adj_verb_df = pd.read_csv("adj_verb_df.csv")
    parse_review(newdata, new_adj_noun_list,new_adjs_verbs_list,new_like_noun, new_dislike_noun,new_size_info,new_recommended_pair, True)
    # t1 = time.time()
    # print(t1 - t0)



 
    t1 = time.time()
    print(t1 - t0)



    ##### Handle the noun list and adj list



    # For the noun list, we need to use the dist to put them in category, neeed ot have certain occurrence
    t0 = time.time()
    new_noun_only = extract_first_elem_text(new_adj_noun_list) + list(map(str, new_like_noun)) + list(map(str, new_dislike_noun))
    new_noun_only = list(filter(lambda x: len(x)>2 and not bool(re.search(r"\d", str(x))) , new_noun_only))
    new_noun_100_freq = Counter(new_noun_only).most_common(100) # the current struct is a list of tuples
    new_noun_only_100 = [str(x[0]) for x in new_noun_100_freq]
    try:
        new_noun_only_100.remove("OBJECT")
    except ValueError:
        pass  
    print(time.time()-t0)

    t0 = time.time()
    new_noun_vector = get_vector_dist(np.append(noun_adj_df["word"].values, new_noun_only_100), pos="n")
    new_knn_clf = KNeighborsClassifier(n_neighbors=2)
    new_knn_clf.fit(new_noun_vector[:len(noun_adj_df)], noun_adj_df["category"])
    new_category = new_knn_clf.predict(new_noun_vector[len(noun_adj_df):])
    print(time.time()-t0)
    # 11 s for 100 reviews

    t0 = time.time()
    new_noun_category_df = pd.DataFrame({"word": new_noun_only_100, "category":new_category})
    new_noun_adj_dict, new_adv_of_adj_dict = construct_dict(new_noun_only_100, list(itertools.chain.from_iterable(new_adj_noun_list)))
    like_dislike_dict = {**{ str(n) : "love" for n in list(map(str, new_like_noun))}, **{str(n): "hate" for n in list(map(str, new_dislike_noun))}}
    print(like_dislike_dict)
    new_noun_category_df['adjs'] = list(map(lambda x: new_noun_adj_dict[x] if new_noun_adj_dict[x] else "love", new_noun_category_df['word']))
    new_noun_100_freq_dict = {x[0]:x[1] for x in new_noun_100_freq}
    new_noun_category_df["count"] = list(map(lambda x: new_noun_100_freq_dict[x], new_noun_category_df['word']))
    print(time.time()-t0)



    # Now we can deal with the verbs
    # we need to add adjs from the nouns of OBJS here
    OBJ_list = list(filter(lambda x: x[0]=='OBJECT', new_adj_noun_list))
    adj_list_above = list(itertools.chain.from_iterable(extract_second_elem_text(OBJ_list)))

    # first extract the adjs
    new_adj_OBJECT = list(filter(lambda x: str(x[0]) in ["OBJECT", "looks", "feels", "look", "feel"], itertools.chain.from_iterable(new_adjs_verbs_list)))
    new_adj_only_count = Counter(adj_list_above+list(itertools.chain.from_iterable(extract_second_elem_text(new_adj_OBJECT))))
    new_adj_80_freq = new_adj_only_count.most_common(80)
    new_adj_only_80 = [str(x[0]) for x in new_adj_80_freq]

    # classify the adj from OBJECT to category
    t3 = time.time()

    new_adj_vector = get_vector_dist(np.append(adj_verb_df["word"].values, new_adj_only_80), pos="a")

    new_knn_verb_clf = KNeighborsClassifier(n_neighbors=2)
    new_knn_verb_clf.fit(new_adj_vector[:len(adj_verb_df)], adj_verb_df["category"])
    new_verb_category = new_knn_verb_clf.predict(new_adj_vector[len(adj_verb_df):])

    new_adj_verb_df = pd.DataFrame({"word":new_adj_only_80,"category":new_verb_category})
    new_adj_80_freq_dict = {str(x[0]):x[1] for x in new_adj_80_freq}
    new_adj_verb_df["count"] = list(map(lambda x: new_adj_80_freq_dict[x], new_adj_verb_df['word']))
    print(time.time()-t3)

    # for the adjs that already have a verb, we could classify them with the verbs
    # the verbs include: Look, Feel, Run, Fit
    new_adj_kept_by_size = list(filter(lambda x: str(x[0]) in ["run", "fit"], itertools.chain.from_iterable(new_adjs_verbs_list)))
    new_adj_only_kept_by_size = list(itertools.chain.from_iterable(extract_second_elem_text(new_adj_kept_by_size)))
    # new_adj_verb_df = pd.DataFrame({"word": new_adj_only_kept_by_size, "category":["size"] * len(new_adj_only_kept_by_size)})

    return [new_adj_noun_list,new_recommended_pair, new_adjs_verbs_list, new_like_noun,         new_dislike_noun, new_size_info, new_adj_verb_df,         new_noun_category_df, new_adv_of_adj_dict ]


# In[795]:


class ReviewAnalyser():
    def __init__(self, text):
        self.new_adj_noun_list = [] 
        self.new_recommended_pair = []
        self.new_adjs_verbs_list = []
        self.new_like_noun = []
        self.new_dislike_noun = []
        self.new_size_info = []
        self.new_adj_verb_df= pd.DataFrame()
        self.new_noun_category_df = pd.DataFrame()
        self.new_adv_of_adj_dict = {}
        self.text = text
        if len(text) > 400:
            self.text = text[:400]
    def startProcessing(self):
        print("start")
        self.new_adj_noun_list,self.new_recommended_pair, self.new_adjs_verbs_list, self.new_like_noun,  self.new_dislike_noun, self.new_size_info, self.new_adj_verb_df,         self.new_noun_category_df, self.new_adv_of_adj_dict = run_the_long_process(self.text)
    def get_printable_category_phrase(self, category):
        picked_df = self.new_noun_category_df[self.new_noun_category_df["category"]==category]
        format_adj = "\t{0}\t\t adv: {1}"
        output_format = """
Word: {0}
Counts: {1}
ADJs: \n{2}
                                
        """
        string_outputs = []
        df_length = len(self.new_noun_category_df)
        for i, r in picked_df.iterrows():
            adj_string_output = ""
            word = r["word"]
            count = r["count"]
            if count < 4 and df_length > 500: 
                continue
            

            adjs = list(map(str, r["adjs"]))
            if str(r["adjs"])=="love":
                formatted_adj_adv = format_adj.format("love", "")
                adj_string_output += formatted_adj_adv + "\n"
                string_outputs.append(output_format.format(word, count, adj_string_output))
                continue
            for adj in adjs:
                cur_string_phrase = word+"_"+adj
                cur_advs = str(self.new_adv_of_adj_dict[cur_string_phrase])
                formatted_adj_adv = format_adj.format(adj, cur_advs)
                adj_string_output += formatted_adj_adv + "\n"
            if len(adjs):
                string_outputs.append(output_format.format(word, count, adj_string_output))
        
        return "".join(string_outputs)
    
    def get_printable_category_verb(self, category):
        picked_df = self.new_adj_verb_df[self.new_adj_verb_df["category"]==category]
        picked_df = picked_df.groupby(["word"])[["count"]].sum()
        picked_df["words"] == picked_df.index
        # return "\n".join("word: {0}, occurrence: {1}".format(t["word"], t["count"]) for t in picked_df)
        return "\n".join("word: {0}, occurrence: {1}".format(t["words"], t["count"]) for i, t in picked_df.iterrows())
    
    def get_recommended_pair(self ):
        filtered_pair = list(set(list(filter(lambda x: not re.search(r"(T|t)his", x), self.new_recommended_pair))))
        def remove_similar(filtered_pair):
            sorted_list = sorted(filtered_pair, key=len, reverse = True)
            i = 0
            while i < len(sorted_list):
                j = i+1
                while j < len(sorted_list):
                    if fuzz.partial_ratio(sorted_list[i],sorted_list[j]) > 70:
                        sorted_list.remove(sorted_list[j])
                    else:
                        j+=1
                i+=1
            return sorted_list
        return "\n".join(remove_similar(filtered_pair))
    def get_new_size_info(self):
        result = [x for x in self.new_size_info if x is not None]
        return pd.DataFrame({"height": x[0], "comment": x[1]} for x in result).sort_values(by=["height"])
  

