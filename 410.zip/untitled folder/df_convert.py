import scrape
import pandas
import json

Asinlist = ['B018LM3CEO']
def getDataFrame(Asinlist):
	DATAFILEPATH = 'data.json'
	scrape.ReadAsin(Asinlist, DATAFILEPATH)
	df = pandas.read_json(DATAFILEPATH)
	return pandas.DataFrame.from_dict(df['reviews'][0])
# df = getDataFrame()
# print(df)